# StockPay Blueprint Website

An interactive HTML visualization of the StockPay fantasy stock platform architecture.